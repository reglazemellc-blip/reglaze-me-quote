// Placeholder hooks for future Google Drive sync
export async function exportToGoogleDrive(_blob: Blob) {
  // TODO: integrate Google Drive API
  console.info('Google Drive sync not implemented yet')
}

export async function importFromGoogleDrive() {
  // TODO: integrate Google Drive API
  console.info('Google Drive import not implemented yet')
}

